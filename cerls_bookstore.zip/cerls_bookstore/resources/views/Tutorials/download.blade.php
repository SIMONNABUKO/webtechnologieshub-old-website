@extends('layouts.app')
@section('content')
<div class="well"> <br><br>
	<a style="background-color: navy; color: white;" class="btn " href="/tutorials">Go back</a>
<br>
	<h1>{{$message}}</h1> <hr>
	

</div>
    

@stop()