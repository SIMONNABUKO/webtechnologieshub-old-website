@extends('layouts.app')
@section('content')
<h1>This post is called:{{$id}}</h1>

@stop();