<?php $__env->startSection('content'); ?>
<div class="well">
	<a style="background-color: navy; color: white;" class="btn " href="/books">Go back</a>

	<h1><?php echo e($book->book_title); ?></h1> <hr>
</div>
<div class="row">
	<div style="background:url(<?php echo e(asset('storage/book_images/'.$book->book_image)); ?>) no-repeat; background-size:100%; margin-bottom:40px;" class="col-lg-4">

	</div>
	<div class="col-lg-8">
		<p><?php echo $book->book_descr; ?></p><br>
		<p>Posted on: <small><?php echo e($book->created_at); ?></small></p><br>
	<a class="btn btn-success" href="<?php echo e($book->link); ?>">Download</a>
		<?php if(!Auth::guest()): ?>
	
		   <?php if(Auth::user()->id == $book->user_id): ?>
		<a style="background-color: #a01b1b; color: white;" class="btn " href="/books/<?php echo e($book->id); ?>/edit">Edit</a><br><br>
	
		<?php echo Form::open(['action'=>['BooksController@destroy', $book->id], 'method'=>'POST', 'class'=>'pull-right']); ?>

	<?php echo e(Form::hidden('_method', 'DELETE')); ?>

	<?php echo e(Form::submit('Delete',  ['class'=>'btn btn-danger'])); ?>

	
		<?php echo Form::close(); ?>

		<?php endif; ?>
	
		<?php endif; ?>
			
	
		
	
	<?php $__env->stopSection(); ?>	
	</div>
</div>
	
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>