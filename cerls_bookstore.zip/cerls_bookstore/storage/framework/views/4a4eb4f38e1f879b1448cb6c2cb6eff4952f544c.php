<?php $__env->startSection('content'); ?>
    

 <div class="row">
     <div class="col-lg-8 col-lg-offset-2">
            <h1>Add a tutorial.</h1>
         
         <?php echo Form::open(array('route'=>'tutorials.store', 'enctype'=>'multipart/form-data')); ?>

         
           <?php echo e(Form::label('tutorial_name', 'Tutorial Name:')); ?>

           <?php echo e(Form::text('tutorial_name', null, array('class'=>'form-control'))); ?>


           <?php echo e(Form::label('tutorial_size', 'Tutorial Size')); ?>

           <?php echo e(Form::number('tutorial_size', null, array('class'=>'form-control'))); ?>


           <?php echo e(Form::label('tutorial_type', 'Tutorial Type')); ?>

           <?php echo e(Form::text('tutorial_type', null, array('class'=>'form-control'))); ?>


           <?php echo e(Form::label('tutorial_path', 'Tutorial Path')); ?>

           <?php echo e(Form::text('tutorial_path', null, array('class'=>'form-control'))); ?>


           <?php echo e(Form::label('tutorial_dirname', 'Tutorial Folder Name')); ?>

           <?php echo e(Form::text('tutorial_dirname', null, array('class'=>'form-control'))); ?>


           <?php echo e(Form::label('tutorial_filename', 'Tutorial File Name')); ?>

           <?php echo e(Form::text('tutorial_filename', null, array('class'=>'form-control'))); ?>

           <?php echo e(Form::label('tutorial_mimetype', 'Tutorial Mimetype')); ?>

           <?php echo e(Form::text('tutorial_mimetype', null, array('class'=>'form-control'))); ?>


           <?php echo e(Form::label('tutorial_extension', 'Tutorial Extension')); ?>

           <?php echo e(Form::text('tutorial_extension', null, array('class'=>'form-control'))); ?>

<br>
           <?php echo e(Form::label('tutorial_image', 'Tutorial Image')); ?>

           <?php echo e(Form::file('tutorial_image', null, array('class'=>'form-control'))); ?>

<br>
           <?php echo e(Form::label('tutorial_description', 'Tutorial Description')); ?>

           <?php echo e(Form::textarea('tutorial_description', null, array('class'=>'form-control'))); ?>

<br>
           <?php echo e(Form::submit('Add Tutorial', array('class'=>'btn btn-sm btn-success btn-block'))); ?>

           
         <?php echo Form::close(); ?>

         <br><br>
     </div>
 </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>