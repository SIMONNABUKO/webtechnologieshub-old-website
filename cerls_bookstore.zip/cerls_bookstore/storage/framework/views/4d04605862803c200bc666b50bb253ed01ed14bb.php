            
            <?php $__env->startSection('content'); ?> <br>
            <h1 style="background-color:#51d8af; border-color:51d8af; color:white" 
            class="btn btn-default">Our Services</h1>
            
<div class="row">
    <div class="col-lg-10">
        <div class="container">
                <?php if(count($services)>0): ?>

                <div class="row">
                   <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               
                   
                        <div style="float:left;  margin-bottom:30px; background:url('storage/service_images/<?php echo e($service->service_image); ?>') no-repeat;" class="col-lg-3 ">
            
                        </div>
                        <div style="float-right" class="col-lg-9">
                                <h2><?php echo e($service->service_title); ?></h2>
                                <p><?php echo e($service->service_description); ?></p>
                                <a style="background-color:#51d8af; color:white; border-color:#51d8af;" class="btn btn-sm btn-info" href="<?php echo e(route('show', $service->id)); ?>">More information</a>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>


        </div>
        
        
    </div>
    <div class="col-lg-2">
        <p>Another column</p>
    </div>
</div>
            
           <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>