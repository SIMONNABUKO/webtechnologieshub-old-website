<?php $__env->startSection('content'); ?>
    

 <div class="row">
     <div class="col-lg-8 col-lg-offset-2">
            <h1>Update tutorial.</h1>
         
         <?php echo Form::open(['action'=> ['TutorialsController@update', $tutorial->id] , 'method'=>'PUT', 'files' => true,  'enctype'=>'multipart/form-data']); ?>

         
           <?php echo e(Form::label('tutorial_name', 'Tutorial Name:')); ?>

           <?php echo e(Form::text('tutorial_name', $tutorial->tutorial_name, array('class'=>'form-control'))); ?>


           <?php echo e(Form::label('tutorial_size', 'Tutorial Size')); ?>

           <?php echo e(Form::number('tutorial_size', $tutorial->tutorial_size, array('class'=>'form-control'))); ?>


           <?php echo e(Form::label('tutorial_type', 'Tutorial Type')); ?>

           <?php echo e(Form::text('tutorial_type', $tutorial->tutorial_type, array('class'=>'form-control'))); ?>


           <?php echo e(Form::label('tutorial_path', 'Tutorial Path')); ?>

           <?php echo e(Form::text('tutorial_path', $tutorial->tutorial_path, array('class'=>'form-control'))); ?>


           <?php echo e(Form::label('tutorial_dirname', 'Tutorial Folder Name')); ?>

           <?php echo e(Form::text('tutorial_dirname', $tutorial->tutorial_dirname, array('class'=>'form-control'))); ?>


           <?php echo e(Form::label('tutorial_filename', 'Tutorial File Name')); ?>

           <?php echo e(Form::text('tutorial_filename', $tutorial->tutorial_filename, array('class'=>'form-control'))); ?>

           
           <?php echo e(Form::label('tutorial_mimetype', 'Tutorial Mimetype')); ?>

           <?php echo e(Form::text('tutorial_mimetype', $tutorial->tutorial_mimetype, array('class'=>'form-control'))); ?>


           <?php echo e(Form::label('tutorial_extension', 'Tutorial Extension')); ?>

           <?php echo e(Form::text('tutorial_extension', $tutorial->tutorial_extension, array('class'=>'form-control'))); ?>

<br>
           <?php echo e(Form::label('tutorial_image', 'Tutorial Image')); ?>

           <?php echo e(Form::file('tutorial_image', null, array('class'=>'form-control'))); ?>

<br>
           <?php echo e(Form::label('tutorial_description', 'Tutorial Description')); ?>

           <?php echo e(Form::textarea('tutorial_description', $tutorial->tutorial_description, array('class'=>'form-control'))); ?>

<br>
           <?php echo e(Form::submit('Update Tutorial', array('class'=>'btn btn-sm btn-success btn-block'))); ?>

           
         <?php echo Form::close(); ?>

         <br><br>
     </div>
 </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>