<?php $__env->startSection('content'); ?>
    <h1>Add a book.</h1>

 <?php echo Form::open(['action'=> ['BooksController@update', $book->id] , 'method'=>'PUT', 'enctype'=>'multipart/form-data']); ?>

    
    <div class="form-group">
    	
    	<?php echo e(FORM::label('book_title', 'Title')); ?>

    	<?php echo e(Form::text('book_title', $book->book_title , ['class'=>'form-control', 'placeholder' => 'Book title'])); ?>

    </div>

    <div class="form-group">
    	
    	<?php echo e(FORM::label('slug', 'Slug')); ?>

    	<?php echo e(Form::text('slug',$book->slug, ['class'=>'form-control', 'placeholder' => 'Tutorial Slug'])); ?>

    </div>

    <div class="form-group">
    	
            <?php echo e(FORM::label('link', 'Tutorial link:')); ?>

            <?php echo e(Form::text('link',$book->link, ['class'=>'form-control', 'placeholder' => 'Tutorial link'])); ?>

        </div>
    
    <div class="form-group">
    	
    	<?php echo e(FORM::label('book_descr', "Book's Description")); ?>

    	<?php echo e(Form::textarea('book_descr',$book->book_descr, ['class'=>'form-control', 'placeholder' => 'Enter a short description about the book', 'id'=>'article-ckeditor'])); ?>

    </div>

    <div class="form-group">
    	
            
            <?php echo e(Form::file('book_image')); ?>

        </div>

    <?php echo e(FORM::hidden('_method', 'PUT')); ?>

    <div class="form-group">
    	
    	
    	<?php echo e(Form::submit('update book', ['class'=> 'btn btn-success'])); ?>

    </div>

<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>