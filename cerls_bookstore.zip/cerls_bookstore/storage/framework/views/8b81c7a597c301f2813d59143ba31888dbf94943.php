<?php $__env->startSection('content'); ?> <br><br>
<div class="row">
    <div class="col-lg-12">
 
 
            <?php echo Form::open(array('action' => 'TutorialsController@search', 'class'=>'form navbar-form navbar-right searchform', 'method'=>'GET')); ?>

            <?php echo Form::text('search', null,
                                   array('required',
                                        'class'=>'form-control',
                                        'placeholder'=>'Search for a tutorial...')); ?>

             <?php echo Form::submit('Search',
                                        array('class'=>'btn btn-default btn-block')); ?>

         <?php echo Form::close(); ?>


 

  

    </div>
</div>
    <h1>e-Books</h1>
    <?php if(count($books)>0): ?>
<div class="row">
	


       <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <div style="background:url('storage/book_images/<?php echo e($book->book_image); ?>') no-repeat; background-size:100%; margin-bottom:40px;" class="col-md-12 col-xs-12 col-sm-12 col-lg-3 col-xl-3">
       

       </div>
       <div style="margin-bottom:40px; margin-left:20px" class="col-md-12 col-xs-12 col-sm-12 col-lg-6 col-xl-6">
       <p class="h2"><a style = "color: #51d8af;"  href="tutorials/<?php echo e($book->id); ?>"> <?php echo e($book->tutorial_name); ?></a></p> 
       
       <p> <?php echo $book->created_at; ?> </p>
       <a class="btn btn-sm btn-dark" href="tutorials/<?php echo e($book->id); ?>">Read more...</a>
       </div>
       <hr style="margin:2px solid navy;">
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           <div class="col-md-12 col-xs-12 col-sm-12 col-lg-3 col-xl-3">
            <p class="h6" style = "color: #330080;"> Book Categories</p> 
            
           
            </div>       
</div>

    <?php else: ?>
    <h2>No books found in the database</h2>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>