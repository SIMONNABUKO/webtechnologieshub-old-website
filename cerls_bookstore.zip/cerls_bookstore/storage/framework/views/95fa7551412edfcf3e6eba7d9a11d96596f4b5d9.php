<?php $__env->startSection('content'); ?>
<div class="well"> <br><br>
	<a style="background-color: navy; color: white;" class="btn " href="/tutorials">Go back</a>
<br>
	<h1 style="color:#51d8af;"><?php echo e($tutorial->tutorial_name); ?></h1> <hr>
	<p>Posted on: <small><?php echo e($tutorial->created_at); ?></small></p><br>
<a class="btn btn-sm btn-success" href="/download/<?php echo e($tutorial->id); ?>">Download</a>
<?php if(Auth::user()): ?>
   <?php if(Auth::user()->email=='simonnabuko@gmail.com'): ?>
   <a  class="btn btn-sm btn-info" href="<?php echo e(route('tutorials.edit', $tutorial->id)); ?>">Edit Tutorial</a>
<?php endif; ?>
<?php endif; ?>   

</div>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>