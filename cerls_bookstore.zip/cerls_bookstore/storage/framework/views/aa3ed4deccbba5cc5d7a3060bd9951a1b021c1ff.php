<?php $__env->startSection('content'); ?>
<div class="well">
	<a style="background-color: navy; color: white;" class="btn " href="/tutorials">Go back</a>

	<h1><?php echo e($content['name']); ?></h1> <hr>
	<p><?php echo $content['mimetype']; ?></p><br>
	<p>Size <small><?php echo e($content['size']); ?></small></p>
	<p>Posted on: <small><?php echo e($content['timestamp']); ?></small></p><br>
	
</div>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>