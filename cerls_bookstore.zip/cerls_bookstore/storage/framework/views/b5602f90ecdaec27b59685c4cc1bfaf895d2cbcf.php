<?php $__env->startSection('content'); ?>
<br>
<h1 style="background-color:#51d8af; border-color:51d8af; color:white" 
class="btn btn-default">Update Service</h1>

<div class="row">
    <div class="col-lg-10 col-lg-offset-2">
<?php echo Form::open(['action'=>['ServicesController@update',$service->id],'method'=>'PUT', 'enctype'=>'multipart/form-data']); ?>

<?php echo e(Form::label('service_title', 'Service Title:')); ?>

<?php echo e(Form::text('service_title', $service->service_title, array('class'=>'form-control'))); ?>


<?php echo e(Form::label('service_description', 'Service Description:')); ?>

<?php echo e(Form::textarea('service_description', $service->service_description, array('class'=>'form-control', 'style'=>'margin-bottom:20px;'))); ?>


<?php echo e(Form::file('service_image')); ?>


<?php echo e(Form::submit('update service', array('class'=>'btn btn-sm btn-success'))); ?>

<?php echo Form::close(); ?>

    </div>
</div>
            
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>