            
            <?php $__env->startSection('content'); ?> <br>
            <div class="owl-carousel owl-theme owl-loaded">
                <div class="owl-stage-outer">
                    <div class="owl-stage">
                    <div class="owl-item"><img src="<?php echo e(asset('storage/slider_images/1.png')); ?>" alt=""></div>
                    <div class="owl-item"><img src="<?php echo e(asset('storage/slider_images/2.png')); ?>" alt=""></div>
                    <div class="owl-item"><img src="<?php echo e(asset('storage/slider_images/3.png')); ?>" alt=""></div>
                    <div class="owl-item"><img src="<?php echo e(asset('storage/slider_images/4.png')); ?>" alt=""></div>
                    </div>
                </div>


            </div>
<div class="row">
    <div class="col-lg-12">
        <h3 style="color:#51d8af;" class="text-center">Who we are</h3>
        <p>Website Technologies Hub
            commonly known as WEBTECHUB
            is a website development, Graphic
            Design and Digital Marketing
            Company fully registered and globally recognized website development company.Our aim is changing the
            web development landscape by
            introducing development of
            websites with marketing incorporated. This is by
            improving the website's SEO as
            opposed to many companies who
            develop for you websites that will
            never appear in the search engine
            results, making no difference
            between having a website and
            having none.
            
            </p>
    </div>
</div>
<?php if(Auth::user()): ?>
   <?php if(Auth::user()->email=='simonnabuko@gmail.com'): ?>
<a class="btn" style="background-color:#51d8af; border-color:51d8af; color:white"  href="/services/create">Add New Service</a>
<?php endif; ?>
<?php endif; ?>           
<h2 class="">Our Services</h2>
            
<div class="row">
    <div class="col-lg-9">
        <div class="container">
                <?php if(count($services)>0): ?>

                <div class="row">
                   <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               
                   
                        <div style="float:left;  margin-bottom:30px; background:url('storage/service_images/<?php echo e($service->service_image); ?>') no-repeat;" class="col-lg-3 ">
            
                        </div>
                        <div style="float-right" class="col-lg-9">
                                <h2><?php echo e($service->service_title); ?></h2>
                                <p><?php echo e(substr($service->service_description, 0, 200)); ?></p>
                                <p>No. of Views: <?php echo e(views($service)->count()); ?></p>
                                <a style="background-color:#51d8af; color:white; border-color:#51d8af;" class="btn btn-sm btn-info" href="/services/show/<?php echo e($service->id); ?>">More information</a>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>


        </div>
        
        
    </div>
    <div class="col-lg-3">
        <p>Another column</p>
    </div>
</div>
            
           <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>