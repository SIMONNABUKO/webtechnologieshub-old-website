<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
<a href="/books/create" class="btn" style="background-color: #330080; color: white;">Add a book</a><br><br><hr>
                    <h6>Books Posted by you</h6><br>

                    <?php if(count($books)> 0): ?>
                    <table class="table table-stripped">
                        
                        <tr>
                            <th>Title</th>
                            <th></th>
                            <th></th>
                        </tr>
                        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <td><?php echo e($book->book_title); ?></td>
                            <td  style="color: #330080;"><a href="/books/<?php echo e($book->id); ?>/edit">Edit</a></td>
                        <td><?php echo Form::open(['action'=>['BooksController@destroy', $book->id], 'method'=>'POST', 'class'=>'pull-right']); ?>

                        <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                        <?php echo e(Form::submit('Delete',  ['class'=>'btn btn-default'])); ?>


                        <?php echo Form::close(); ?></td>
                        </tr>


                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                    <?php else: ?>
                    <p>There are no books added by you</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>