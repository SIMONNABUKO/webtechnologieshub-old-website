<?php $__env->startSection('content'); ?> <br><br>

<div class="row">
        <div class="col-lg-12">
     
     
                <?php echo Form::open(array('action' => 'TutorialsController@search', 'class'=>'form navbar-form navbar-right searchform', 'method'=>'GET')); ?>

                <?php echo Form::text('search', null,
                                       array('required',
                                            'class'=>'form-control',
                                            'placeholder'=>'Search for e-book...')); ?>

                 <?php echo Form::submit('Search',
                                            array('class'=>'btn btn-default btn-block')); ?>

             <?php echo Form::close(); ?>

    
     
    
      
    
        </div>
    </div>
    <h1 class="btn btn-dark" style="border-color:#51d8af; background-color:#51d8af; color:white;">e-Books</h1>
    <?php if(count($tutorials)>0): ?>
<div class="row">
<div class="col-lg-9" style="border-right: 1px solid navy;">

    <div class="row">
        <table class="table table-stripped">
            <thead>
                <tr>
                <td>Book Name</td>
                <td>Date Added</td>
                <td>More Information</td>
                <td>Total Views</td>
                
            </tr>
            </thead>
            <tbody>
                    <?php $__currentLoopData = $tutorials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tutorial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <th><a style = "color: #51d8af;" href="<?php echo e(route('tutorials.show', $tutorial->id)); ?>"><?php echo $tutorial->tutorial_name; ?></a></th>
                    <th><?php echo $tutorial->created_at; ?></th>
                    <th><a style="border-color:navy; background-color:navy; color:white;" class="btn btn-sm btn-dark" href="<?php echo e(route('tutorials.show', $tutorial->id)); ?>">Download</a></th>
                    
                <th><?php echo e(views($tutorial)->count()); ?></th>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    </div>
       
        </div>
        <div class="col-lg-3">
            <p class="btn btn-dark" class="h4" style = "border-color:navy; background-color: navy;color:white;"> Book Categories</p> 
        </div>
                    
</div>
<div  class="text-center">
  <p style = "color: #51d8af;" class="text-justify"><?php echo e($tutorials->links()); ?></p>
</div>

    <?php else: ?>
    <h2>No tutorials found in the database</h2>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>